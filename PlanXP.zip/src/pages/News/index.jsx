import React from "react";
import NewsContent from "../../components/NewsContent";
const News = () => {
  return <NewsContent />;
};

export default News;
