import React from "react";
import ContactContent from "../../components/ContactContent";
const Contact = () => {
  return <ContactContent />;
};

export default Contact;
