import React from "react";
import GamesContent from "../../components/GamesContent";
const Games = () => {
  return (
      <GamesContent />
  );
};

export default Games;
